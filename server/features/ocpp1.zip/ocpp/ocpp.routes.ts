import { Router } from 'express';
import { 
  sendRemoteStart, 
  sendRemoteStop,
  sendChangeAvailability,
  sendClearCache,
  sendReset
} from './ocppClient';

const router = Router();

// Consultar estado de un cargador OCPP
router.get('/status/:serial', async (req, res) => {
  // Aquí puedes consultar la base de datos o el estado en memoria
  // Ejemplo básico:
  // const status = await getChargerStatus(req.params.serial);
  res.json({ status: 'standby' });
});

// Enviar comando remoto (ejemplo: iniciar carga)
router.post('/remote-start/:serial', async (req, res) => {
  try {
    const { userId } = req.body;
    const result = await sendRemoteStart(req.params.serial, userId);
    res.json({ ok: true, result });
  } catch (err: any) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

// Enviar comando remoto (ejemplo: parar carga)
router.post('/remote-stop/:serial', async (req, res) => {
  try {
    const { transactionId } = req.body;
    const result = await sendRemoteStop(req.params.serial, transactionId);
    res.json({ ok: true, result });
  } catch (err: any) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

// Cambiar disponibilidad de un conector
router.post('/change-availability/:serial', async (req, res) => {
  try {
    const { connectorId, type } = req.body;
    const result = await sendChangeAvailability(req.params.serial, connectorId, type);
    res.json({ ok: true, result });
  } catch (err: any) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

// Limpiar caché de autorización
router.post('/clear-cache/:serial', async (req, res) => {
  try {
    const result = await sendClearCache(req.params.serial);
    res.json({ ok: true, result });
  } catch (err: any) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

// Reiniciar un cargador
router.post('/reset/:serial', async (req, res) => {
  try {
    const { type } = req.body;
    const result = await sendReset(req.params.serial, type);
    res.json({ ok: true, result });
  } catch (err: any) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

export default router; 