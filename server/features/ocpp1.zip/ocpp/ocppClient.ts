// @ts-ignore
import { OCPPCommands } from 'ocpp-js';
import { ocppServer } from './ocppServer';


// Mantener referencia a los clientes conectados
const connectedClients: Map<string, any> = new Map();

// Hook para registrar clientes al conectarse
export function registerOcppClient(client: any) {
  connectedClients.set(client.id, client);
}

export function unregisterOcppClient(client: any) {
  connectedClients.delete(client.id);
}

// Enviar comando remoto para iniciar carga
export async function sendRemoteStart(serial: string, userId: number) {
  const client = connectedClients.get(serial);
  if (!client) throw new Error('Cargador no conectado');
  return new Promise((resolve, reject) => {
    client.request(OCPPCommands.RemoteStartTransaction, {
      idTag: String(userId),
      connectorId: 1,
    }, (response: any) => {
      resolve(response);
    });
  });
}

// Enviar comando remoto para parar carga
export async function sendRemoteStop(serial: string, transactionId: number) {
  const client = connectedClients.get(serial);
  if (!client) throw new Error('Cargador no conectado');
  return new Promise((resolve, reject) => {
    client.request(OCPPCommands.RemoteStopTransaction, {
      transactionId,
    }, (response: any) => {
      resolve(response);
    });
  });
}

// Enviar comando de reinicio
export async function sendReset(serial: string, type: 'Hard' | 'Soft') {
  const client = connectedClients.get(serial);
  if (!client) throw new Error('Cargador no conectado');
  return new Promise((resolve, reject) => {
    client.request(OCPPCommands.Reset, {
      type
    }, (response: any) => {
      resolve(response);
    });
  });
}

// Enviar comando para desbloquear conector
export async function sendUnlockConnector(serial: string, connectorId: number) {
  const client = connectedClients.get(serial);
  if (!client) throw new Error('Cargador no conectado');
  return new Promise((resolve, reject) => {
    client.request(OCPPCommands.UnlockConnector, {
      connectorId
    }, (response: any) => {
      resolve(response);
    });
  });
}

// Enviar comando para cambiar configuración
export async function sendChangeConfiguration(serial: string, key: string, value: string) {
  const client = connectedClients.get(serial);
  if (!client) throw new Error('Cargador no conectado');
  return new Promise((resolve, reject) => {
    client.request(OCPPCommands.ChangeConfiguration, {
      key,
      value
    }, (response: any) => {
      resolve(response);
    });
  });
}

// Enviar comando para obtener configuración
export async function sendGetConfiguration(serial: string, keys?: string[]) {
  const client = connectedClients.get(serial);
  if (!client) throw new Error('Cargador no conectado');
  return new Promise((resolve, reject) => {
    const payload: any = {};
    if (keys && keys.length > 0) {
      payload.key = keys;
    }
    
    client.request(OCPPCommands.ChangeConfiguration, payload, (response: any) => {
      resolve(response);
    });
  });
}

// Enviar comando para actualizar firmware
export async function sendUpdateFirmware(
  serial: string, 
  location: string, 
  retrieveDate: string, 
  retries?: number, 
  retryInterval?: number
) {
  const client = connectedClients.get(serial);
  if (!client) throw new Error('Cargador no conectado');
  return new Promise((resolve, reject) => {
    const payload: any = {
      location,
      retrieveDate
    };
    
    if (retries !== undefined) {
      payload.retries = retries;
    }
    
    if (retryInterval !== undefined) {
      payload.retryInterval = retryInterval;
    }
    
    client.request(OCPPCommands.UpdateFirmware, payload, (response: any) => {
      resolve(response);
    });
  });
}

// Enviar comando para obtener diagnósticos
export async function sendGetDiagnostics(
  serial: string,
  location: string,
  startTime?: string,
  stopTime?: string,
  retries?: number,
  retryInterval?: number
) {
  const client = connectedClients.get(serial);
  if (!client) throw new Error('Cargador no conectado');
  return new Promise((resolve, reject) => {
    const payload: any = {
      location
    };
    
    if (startTime) {
      payload.startTime = startTime;
    }
    
    if (stopTime) {
      payload.stopTime = stopTime;
    }
    
    if (retries !== undefined) {
      payload.retries = retries;
    }
    
    if (retryInterval !== undefined) {
      payload.retryInterval = retryInterval;
    }
    
    client.request(OCPPCommands.GetDiagnostics, payload, (response: any) => {
      resolve(response);
    });
  });
}

// Enviar comando para establecer perfil de carga
export async function sendSetChargingProfile(
  serial: string,
  connectorId: number,
  chargingProfile: any
) {
  const client = connectedClients.get(serial);
  if (!client) throw new Error('Cargador no conectado');
  return new Promise((resolve, reject) => {
    client.request(OCPPCommands.SetChargingProfile, {
      connectorId,
      csChargingProfiles: chargingProfile
    }, (response: any) => {
      resolve(response);
    });
  });
}

// Enviar comando para cambiar la disponibilidad de un conector
export async function sendChangeAvailability(serial: string, connectorId: number, type: 'Inoperative' | 'Operative') {
  const client = connectedClients.get(serial);
  if (!client) throw new Error('Cargador no conectado');
  return new Promise((resolve, reject) => {
    client.request(OCPPCommands.ChangeAvailability, {
      connectorId,
      type
    }, (response: any) => {
      resolve(response);
    });
  });
}

// Enviar comando para limpiar la caché de autorización
export async function sendClearCache(serial: string) {
  const client = connectedClients.get(serial);
  if (!client) throw new Error('Cargador no conectado');
  return new Promise((resolve, reject) => {
    client.request(OCPPCommands.ClearCache, {}, (response: any) => {
      resolve(response);
    });
  });
}