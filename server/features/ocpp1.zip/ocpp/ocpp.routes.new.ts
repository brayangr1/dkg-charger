import { Router } from 'express';
import { 
  sendRemoteStart, 
  sendRemoteStop,
  sendReset,
  sendUnlockConnector,
  sendChangeConfiguration,
  sendGetConfiguration,
  sendUpdateFirmware,
  sendGetDiagnostics,
  sendSetChargingProfile
} from './ocppClient';

const router = Router();

/**
 * GET /status/:serial
 * Consultar el estado actual de un cargador OCPP por su número de serie
 * Esta ruta permite obtener el estado actual del cargador, incluyendo información 
 * sobre su disponibilidad, estado de conexión y otros parámetros operativos.
 */
router.get('/status/:serial', async (req, res) => {
  // TODO: Implementar consulta real del estado del cargador
  // Debería consultar la base de datos o el estado en memoria
  res.json({ status: 'standby' });
});

/**
 * POST /remote-start/:serial
 * Enviar comando remoto para iniciar una transacción de carga
 * Permite iniciar una sesión de carga de forma remota especificando el ID de usuario
 */
router.post('/remote-start/:serial', async (req, res) => {
  try {
    const { userId } = req.body;
    const result = await sendRemoteStart(req.params.serial, userId);
    res.json({ ok: true, result });
  } catch (err: any) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

/**
 * POST /remote-stop/:serial
 * Enviar comando remoto para detener una transacción de carga
 * Permite detener una sesión de carga en curso especificando el ID de transacción
 */
router.post('/remote-stop/:serial', async (req, res) => {
  try {
    const { transactionId } = req.body;
    const result = await sendRemoteStop(req.params.serial, transactionId);
    res.json({ ok: true, result });
  } catch (err: any) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

/**
 * POST /reset/:serial
 * Enviar comando para reiniciar un cargador OCPP
 * Permite reiniciar el cargador de forma remota, útil para aplicar configuraciones 
 * o recuperar el cargador de estados no deseados.
 * Tipos de reinicio:
 * - Hard: Reinicio completo del cargador
 * - Soft: Reinicio del software de aplicación
 */
router.post('/reset/:serial', async (req, res) => {
  try {
    const { type } = req.body; // "Hard" o "Soft"
    const result = await sendReset(req.params.serial, type);
    res.json({ ok: true, result });
  } catch (err: any) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

/**
 * POST /unlock-connector/:serial
 * Enviar comando para desbloquear un conector del cargador
 * Útil cuando un vehículo no puede desconectarse normalmente del cargador
 */
router.post('/unlock-connector/:serial', async (req, res) => {
  try {
    const { connectorId } = req.body; // ID del conector a desbloquear (por defecto 1)
    const result = await sendUnlockConnector(req.params.serial, connectorId || 1);
    res.json({ ok: true, result });
  } catch (err: any) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

/**
 * POST /change-configuration/:serial
 * Cambiar la configuración de un cargador OCPP
 * Permite modificar parámetros de configuración del cargador de forma remota
 */
router.post('/change-configuration/:serial', async (req, res) => {
  try {
    const { key, value } = req.body; // Clave y valor de configuración a cambiar
    const result = await sendChangeConfiguration(req.params.serial, key, value);
    res.json({ ok: true, result });
  } catch (err: any) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

/**
 * POST /get-configuration/:serial
 * Obtener la configuración actual de un cargador OCPP
 * Permite consultar los parámetros de configuración actuales del cargador
 */
router.post('/get-configuration/:serial', async (req, res) => {
  try {
    const { keys } = req.body; // Array opcional de claves específicas a consultar
    const result = await sendGetConfiguration(req.params.serial, keys);
    res.json({ ok: true, result });
  } catch (err: any) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

/**
 * POST /update-firmware/:serial
 * Iniciar actualización de firmware en un cargador OCPP
 * Permite actualizar el firmware del cargador de forma remota
 */
router.post('/update-firmware/:serial', async (req, res) => {
  try {
    const { location, retrieveDate, retries, retryInterval } = req.body;
    const result = await sendUpdateFirmware(
      req.params.serial, 
      location, 
      retrieveDate, 
      retries, 
      retryInterval
    );
    res.json({ ok: true, result });
  } catch (err: any) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

/**
 * POST /get-diagnostics/:serial
 * Solicitar diagnósticos de un cargador OCPP
 * Permite obtener información de diagnóstico del cargador
 */
router.post('/get-diagnostics/:serial', async (req, res) => {
  try {
    const { location, startTime, stopTime, retries, retryInterval } = req.body;
    const result = await sendGetDiagnostics(
      req.params.serial,
      location,
      startTime,
      stopTime,
      retries,
      retryInterval
    );
    res.json({ ok: true, result });
  } catch (err: any) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

/**
 * POST /set-charging-profile/:serial
 * Establecer un perfil de carga para un cargador OCPP
 * Permite controlar dinámicamente la potencia de carga según políticas definidas
 */
router.post('/set-charging-profile/:serial', async (req, res) => {
  try {
    const { connectorId, chargingProfile } = req.body;
    const result = await sendSetChargingProfile(
      req.params.serial,
      connectorId,
      chargingProfile
    );
    res.json({ ok: true, result });
  } catch (err: any) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

export default router;