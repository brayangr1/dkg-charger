declare module 'ocpp-js' {
    export class OCPPServer {
        constructor(options: { server: any; protocols: string[] });
        on(event: 'connection' | 'request' | 'close', listener: (client: any, ...args: any[]) => void): this;
    }

    export enum OCPPCommands {
        BootNotification = 'BootNotification',
        Heartbeat = 'Heartbeat',
        StatusNotification = 'StatusNotification',
        StartTransaction = 'StartTransaction',
        StopTransaction = 'StopTransaction',
        MeterValues = 'MeterValues',
        DiagnosticsStatusNotification = 'DiagnosticsStatusNotification',
        FirmwareStatusNotification = 'FirmwareStatusNotification',
        RemoteStartTransaction = "RemoteStartTransaction",
        RemoteStopTransaction = "RemoteStopTransaction",
        Reset = "Reset",
        UnlockConnector = "UnlockConnector",
        ChangeConfiguration = "ChangeConfiguration",
        UpdateFirmware = "UpdateFirmware",
        GetDiagnostics = "GetDiagnostics",
        SetChargingProfile = "SetChargingProfile",
        ChangeAvailability = "ChangeAvailability",
        ClearCache = "ClearCache"
    }

    export enum OCPPProtocol {
        OCPP16 = 'ocpp1.6'
    }
}