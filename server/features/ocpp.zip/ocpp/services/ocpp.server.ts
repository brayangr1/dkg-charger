import WebSocket from 'ws';
import { v4 as uuidv4 } from 'uuid';
import { OCPPDatabaseService } from './ocpp.database.service';
import {
    OCPPMessage,
    ChargePointConnection,
    OCPPAction,
    OCPPStatus,
    ChargePointStatus,
    BootNotificationRequest,
    BootNotificationResponse,
    HeartbeatRequest,
    HeartbeatResponse,
    AuthorizeRequest,
    AuthorizeResponse,
    OCPPRequest,
    OCPPResponse,
    OCPPError,
    MessageType
} from '../types/ocpp.types';

class OCPPServer {
    private wss: WebSocket.Server;
    private connections: Map<string, ChargePointConnection>;
    private heartbeatInterval: number = 300; // 5 minutes
    private dbService: OCPPDatabaseService;

    constructor(port: number = 5010) {
        this.wss = new WebSocket.Server({ port });
        this.connections = new Map();
        this.dbService = new OCPPDatabaseService();
        this.setupWebSocketServer();
        console.log(`🔌 Servidor OCPP iniciado en puerto ${port}`);
    }

    private setupWebSocketServer() {
        this.wss.on('connection', (ws: WebSocket, req: any) => {
            // Extraer el ID del punto de carga de la URL
            const chargePointId = this.extractChargePointId(req.url);
            if (!chargePointId) {
                console.error('ID de punto de carga no proporcionado');
                ws.close();
                return;
            }

            // Registrar nueva conexión
            this.connections.set(chargePointId, {
                wsConnection: ws,
                chargePointId,
                lastHeartbeat: new Date(),
                status: ChargePointStatus.Available
            });

            console.log(`✅ Punto de carga conectado: ${chargePointId}`);

            // Configurar handlers
            ws.on('message', async (message: string) => {
                try {
                    const parsed = JSON.parse(message.toString()) as [MessageType, ...any[]];
                    await this.handleOCPPMessage(ws, chargePointId, parsed);
                } catch (error) {
                    console.error('Error procesando mensaje:', error);
                    this.sendError(ws, "MessageFormatError", "Invalid message format");
                }
            });

            ws.on('close', () => {
                console.log(`❌ Punto de carga desconectado: ${chargePointId}`);
                this.connections.delete(chargePointId);
            });

            ws.on('error', (error) => {
                console.error(`Error en conexión ${chargePointId}:`, error);
                this.connections.delete(chargePointId);
            });
        });
    }

    private extractChargePointId(url: string): string | null {
        const match = url.match(/\/ocpp\/([^/]+)$/);
        return match ? match[1] : null;
    }

    private async handleOCPPMessage(
        ws: WebSocket,
        chargePointId: string,
        message: [MessageType, ...any[]]
    ) {
        const messageTypeId = message[0] as MessageType;

        if (typeof messageTypeId !== 'number' || ![2, 3, 4].includes(messageTypeId)) {
            this.sendError(ws, "MessageTypeError", "Invalid message type");
            return;
        }

        if (messageTypeId === 2) { // Request
            const [, uniqueId, action, payload] = message as OCPPRequest;
            if (typeof action !== 'string' || typeof uniqueId !== 'string') {
                this.sendError(ws, "MessageFormatError", "Invalid message format");
                return;
            }
            await this.handleRequest(ws, chargePointId, uniqueId, action, payload);
        } else if (messageTypeId === 3) { // Response
            const [, uniqueId, payload] = message as OCPPResponse;
            // Manejar respuestas si es necesario
            console.log('Respuesta recibida:', { uniqueId, payload });
        } else if (messageTypeId === 4) { // Error
            const [, uniqueId, errorCode, errorDescription, errorDetails] = message as OCPPError;
            console.error(`Error from ${chargePointId}:`, { errorCode, errorDescription, errorDetails });
        }
    }

    private async handleRequest(
        ws: WebSocket,
        chargePointId: string,
        uniqueId: string,
        action: string,
        payload: any
    ) {
        switch (action) {
            case OCPPAction.BootNotification:
                await this.handleBootNotification(ws, chargePointId, uniqueId, payload);
                break;
            case OCPPAction.Heartbeat:
                await this.handleHeartbeat(ws, chargePointId, uniqueId);
                break;
            case OCPPAction.Authorize:
                await this.handleAuthorize(ws, uniqueId, payload);
                break;
            default:
                console.warn(`Acción no implementada: ${action}`);
                this.sendError(ws, "NotImplemented", `Action ${action} not implemented`);
        }
    }

    private async handleBootNotification(
        ws: WebSocket,
        chargePointId: string,
        uniqueId: string,
        payload: BootNotificationRequest
    ) {
        console.log('Boot Notification recibida:', payload);

        try {
            await this.dbService.registerBootNotification(chargePointId, payload);
            
            const response: BootNotificationResponse = {
                status: OCPPStatus.Accepted,
                currentTime: new Date().toISOString(),
                interval: this.heartbeatInterval
            };

            this.sendResponse(ws, uniqueId, response);
        } catch (error) {
            console.error('Error procesando Boot Notification:', error);
            this.sendError(ws, "InternalError", "Error processing boot notification");
        }
    }

    private async handleHeartbeat(
        ws: WebSocket,
        chargePointId: string,
        uniqueId: string
    ) {
        const connection = this.connections.get(chargePointId);
        if (connection) {
            connection.lastHeartbeat = new Date();
        }

        const response: HeartbeatResponse = {
            currentTime: new Date().toISOString()
        };

        this.sendResponse(ws, uniqueId, response);
    }

    private async handleAuthorize(
        ws: WebSocket,
        uniqueId: string,
        payload: AuthorizeRequest
    ) {
        console.log('Autorización solicitada para:', payload.idTag);

        // Aquí implementarías la lógica de autorización real
        const response: AuthorizeResponse = {
            idTagInfo: {
                status: OCPPStatus.Accepted,
                expiryDate: new Date(Date.now() + 86400000).toISOString() // 24 horas
            }
        };

        this.sendResponse(ws, uniqueId, response);
    }

    private sendResponse(ws: WebSocket, uniqueId: string, payload: any) {
        const response: OCPPMessage = {
            messageTypeId: 3,
            uniqueId,
            payload
        };
        ws.send(JSON.stringify([response.messageTypeId, response.uniqueId, response.payload]));
    }

    private sendError(ws: WebSocket, errorCode: string, errorDescription: string) {
        const errorResponse: OCPPMessage = {
            messageTypeId: 4,
            uniqueId: uuidv4(),
            payload: {
                errorCode,
                errorDescription
            }
        };
        ws.send(JSON.stringify([
            errorResponse.messageTypeId,
            errorResponse.uniqueId,
            errorCode,
            errorDescription,
            {}
        ]));
    }

    // Método público para obtener estado de los cargadores
    public getChargePointsStatus(): { [key: string]: ChargePointStatus } {
        const status: { [key: string]: ChargePointStatus } = {};
        this.connections.forEach((connection, chargePointId) => {
            status[chargePointId] = connection.status;
        });
        return status;
    }

    // Método para enviar comando a un cargador específico
    public async sendCommand(chargePointId: string, command: string, payload: any): Promise<boolean> {
        const connection = this.connections.get(chargePointId);
        if (!connection) {
            console.error(`Cargador ${chargePointId} no conectado`);
            return false;
        }

        try {
            const messageId = uuidv4();
            const message: OCPPMessage = {
                messageTypeId: 2,
                uniqueId: messageId,
                action: command,
                payload
            };

            connection.wsConnection.send(JSON.stringify([
                message.messageTypeId,
                message.uniqueId,
                message.action,
                message.payload
            ]));
            return true;
        } catch (error) {
            console.error(`Error enviando comando a ${chargePointId}:`, error);
            return false;
        }
    }
}

export default OCPPServer;