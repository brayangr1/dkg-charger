import { OCPPServer, OCPPCommands, OCPPProtocol } from 'ocpp-js';
import http from 'http';
import { connectionPool } from '../../config/db.config';
import { registerOcppClient, unregisterOcppClient } from './ocppClient';
import { RowDataPacket } from 'mysql2/promise';

// Interfaces para TypeScript
interface OCPPClient {
    id: string;
    on(event: string, callback: Function): void;
    send(command: string, payload: any): void;
}

interface BootNotificationPayload {
    chargePointModel: string;
    chargePointVendor: string;
    firmwareVersion?: string;
}

interface StatusNotificationPayload {
    connectorId: number;
    status: string;
    errorCode: string;
}

interface StartTransactionPayload {
    connectorId: number;
    idTag: string;
    meterStart: number;
    timestamp: string;
}

interface StopTransactionPayload {
    transactionId: number;
    meterStop: number;
    timestamp: string;
    reason?: string;
}

// Configuración del servidor HTTP para OCPP (puede ser el mismo que Express o uno dedicado)
const OCPP_PORT = process.env.OCPP_PORT ? parseInt(process.env.OCPP_PORT) : 5010;
const server = http.createServer();

// Crear instancia del servidor OCPP (OCPP 1.6 JSON)
const ocppServer = new OCPPServer({
  server,
  protocols: [OCPPProtocol.OCPP16],
});

// Manejar eventos de conexión de un cargador
ocppServer.on('connection', (client: any) => {
  registerOcppClient(client);
  console.log(`[OCPP] Nueva conexión de cargador: ${client.id}`);

  client.on('request', async (command: any, payload: any, cb: any) => {
    console.log(`[OCPP] Mensaje recibido: ${command} de ${client.id}`);
    switch (command) {
      case OCPPCommands.BootNotification:
        await handleBootNotification(client, payload);
        cb({
          currentTime: new Date().toISOString(),
          interval: 300, // Intervalo de Heartbeat recomendado
          status: 'Accepted',
        });
        break;
      case OCPPCommands.Heartbeat:
        await handleHeartbeat(client, payload);
        cb({
          currentTime: new Date().toISOString(),
        });
        break;
      case OCPPCommands.StatusNotification:
        await handleStatusNotification(client, payload);
        cb({});
        break;
      case OCPPCommands.StartTransaction:
        const startRes = await handleStartTransaction(client, payload);
        cb(startRes);
        break;
      case OCPPCommands.StopTransaction:
        const stopRes = await handleStopTransaction(client, payload);
        cb(stopRes);
        break;
      case OCPPCommands.MeterValues:
        await handleMeterValues(client, payload);
        cb({});
        break;
      case OCPPCommands.DiagnosticsStatusNotification:
        await handleDiagnosticsStatusNotification(client, payload);
        cb({});
        break;
      case OCPPCommands.FirmwareStatusNotification:
        await handleFirmwareStatusNotification(client, payload);
        cb({});
        break;
      default:
        cb({});
    }
  });

  client.on('close', () => {
    unregisterOcppClient(client);
    console.log(`[OCPP] Cargador desconectado: ${client.id}`);
    setChargerNetworkStatus(client.id, 'offline');
  });
});

// Iniciar el servidor OCPP
server.listen(OCPP_PORT, () => {
  console.log(`[OCPP] Servidor OCPP escuchando en el puerto ${OCPP_PORT}`);
});

// --- Handlers ---

async function handleBootNotification(client: any, payload: any) {
  // payload: {chargePointModel, chargePointVendor, ...}
  // Actualiza o inserta el cargador en la base de datos
  const serial = client.id;
  const model = payload.chargePointModel || 'Unknown';
  const firmware = payload.firmwareVersion || 'Unknown';
  try {
    await connectionPool.query(
      `INSERT INTO chargers (serial_number, name, model, firmware_version, network_status, status, last_updated)
       VALUES (?, ?, ?, ?, 'online', 'standby', NOW())
       ON DUPLICATE KEY UPDATE model = VALUES(model), firmware_version = VALUES(firmware_version), network_status = 'online', last_updated = NOW()`,
      [serial, serial, model, firmware]
    );
    console.log(`[OCPP] BootNotification procesado para ${serial}`);
  } catch (err) {
    console.error('[OCPP] Error en BootNotification:', err);
  }
}

async function handleHeartbeat(client: any, payload: any) {
  const serial = client.id;
  console.log(`[OCPP] Heartbeat recibido de ${serial}`);
  try {
    await connectionPool.query(
      `UPDATE chargers SET last_updated = NOW(), network_status = 'online' WHERE serial_number = ?`,
      [serial]
    );
  } catch (err) {
    console.error('[OCPP] Error actualizando last_updated en Heartbeat:', err);
  }
}

async function handleDiagnosticsStatusNotification(client: any, payload: any) {
  const serial = client.id;
  const status = payload.status; // e.g., 'Uploaded', 'UploadFailed'
  console.log(`[OCPP] DiagnosticsStatusNotification de ${serial}: ${status}`);
  try {
    await connectionPool.query(
      `INSERT INTO charger_logs (charger_id, action_type, raw_data) SELECT id, 'diagnostics_status', ? FROM chargers WHERE serial_number = ?`,
      [JSON.stringify(payload), serial]
    );
  } catch (err) {
    console.error('[OCPP] Error en DiagnosticsStatusNotification:', err);
  }
}

async function handleFirmwareStatusNotification(client: any, payload: any) {
  const serial = client.id;
  const status = payload.status; // e.g., 'Downloaded', 'DownloadFailed', 'Installed', 'InstallationFailed'
  console.log(`[OCPP] FirmwareStatusNotification de ${serial}: ${status}`);
  try {
    await connectionPool.query(
      `INSERT INTO charger_logs (charger_id, action_type, raw_data) SELECT id, 'firmware_status', ? FROM chargers WHERE serial_number = ?`,
      [JSON.stringify(payload), serial]
    );
  } catch (err) {
    console.error('[OCPP] Error en FirmwareStatusNotification:', err);
  }
}


async function handleStatusNotification(client: any, payload: any) {
  // payload: {connectorId, status, errorCode, ...}
  const serial = client.id;
  const status = payload.status?.toLowerCase() || 'standby';
  try {
    await connectionPool.query(
      `UPDATE chargers SET status = ?, last_updated = NOW(), network_status = 'online' WHERE serial_number = ?`,
      [status, serial]
    );
    console.log(`[OCPP] StatusNotification: ${serial} => ${status}`);
  } catch (err) {
    console.error('[OCPP] Error en StatusNotification:', err);
  }
}

async function setChargerNetworkStatus(serial: string, status: 'online' | 'offline') {
  try {
    await connectionPool.query(
      `UPDATE chargers SET network_status = ?, last_updated = NOW() WHERE serial_number = ?`,
      [status, serial]
    );
  } catch (err) {
    console.error('[OCPP] Error actualizando network_status:', err);
  }
}

// --- Handlers extendidos ---

async function handleStartTransaction(client: any, payload: any) {
  // payload: {connectorId, idTag, meterStart, timestamp}
  // Crear sesión de carga
  try {
    // Buscar user_id por idTag (puede ser el id del usuario)
    const [userRows] = await connectionPool.query<RowDataPacket[]>(
      'SELECT id FROM users WHERE id = ?', [payload.idTag]
    );
    if (!userRows || userRows.length === 0) {
      return { idTagInfo: { status: 'Invalid' }, transactionId: null };
    }
    const userId = userRows[0].id;
    // Crear sesión
    const [result]: any = await connectionPool.query(
      `INSERT INTO charging_sessions (charger_id, user_id, start_time, charging_mode)
       SELECT id, ?, NOW(), 'grid' FROM chargers WHERE serial_number = ?`,
      [userId, client.id]
    );
    const transactionId = result.insertId;
    // Log
    await connectionPool.query(
      `INSERT INTO charger_logs (charger_id, action_type, raw_data) SELECT id, 'start_transaction', ? FROM chargers WHERE serial_number = ?`,
      [JSON.stringify(payload), client.id]
    );
    return { idTagInfo: { status: 'Accepted' }, transactionId };
  } catch (err) {
    console.error('[OCPP] Error en StartTransaction:', err);
    return { idTagInfo: { status: 'Invalid' }, transactionId: null };
  }
}

async function handleStopTransaction(client: any, payload: any) {
  // payload: {transactionId, meterStop, timestamp, reason}
  try {
    // Actualizar sesión
    await connectionPool.query(
      `UPDATE charging_sessions SET end_time = NOW(), duration_seconds = TIMESTAMPDIFF(SECOND, start_time, NOW()) WHERE id = ?`,
      [payload.transactionId]
    );
    // Log
    await connectionPool.query(
      `INSERT INTO charger_logs (charger_id, action_type, raw_data) SELECT id, 'stop_transaction', ? FROM chargers WHERE serial_number = ?`,
      [JSON.stringify(payload), client.id]
    );
    return { idTagInfo: { status: 'Accepted' } };
  } catch (err) {
    console.error('[OCPP] Error en StopTransaction:', err);
    return { idTagInfo: { status: 'Invalid' } };
  }
}

async function handleMeterValues(client: any, payload: any) {
  // payload: {connectorId, transactionId, meterValue: [{timestamp, sampledValue: [{value, measurand, unit}]}]}
  try {
    // Guardar valores de consumo en logs o tabla específica
    await connectionPool.query(
      `INSERT INTO charger_logs (charger_id, action_type, raw_data) SELECT id, 'meter_values', ? FROM chargers WHERE serial_number = ?`,
      [JSON.stringify(payload), client.id]
    );
    // Puedes extender para guardar valores en charging_sessions si lo deseas
  } catch (err) {
    console.error('[OCPP] Error en MeterValues:', err);
  }
}

export { ocppServer };

// El declare module se ha movido al archivo types/ocpp-js.d.ts 