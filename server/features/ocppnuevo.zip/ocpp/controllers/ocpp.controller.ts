// server/features/ocpp/ocpp.controller.ts
import { Router } from 'express';
import { OCPPService } from '../services/ocpp.service';
import { connectionPool } from '../../../config/db.config';

const router = Router();
const ocppService = new OCPPService();

// Obtener estado de cargadores conectados
router.get('/connected-chargers', async (req, res) => {
    try {
        const connectedChargers = ocppService.getConnectedChargers();
        res.json({ success: true, chargers: connectedChargers });
    } catch (error) {
        console.error('Error obteniendo cargadores conectados:', error);
        res.status(500).json({ success: false, error: 'Error interno' });
    }
});

// Verificar estado de un cargador específico
router.get('/status/:serial', async (req, res) => {
    try {
        const { serial } = req.params;
        
        // Verificar en base de datos
        const [dbRows] = await connectionPool.query(
            'SELECT id, serial_number, status, network_status, last_updated FROM chargers WHERE serial_number = ?',
            [serial]
        );

        const chargers = dbRows as any[];
        
        if (chargers.length === 0) {
            return res.status(404).json({ 
                success: false, 
                error: 'Cargador no encontrado en base de datos' 
            });
        }

        const charger = chargers[0];
        const isConnected = ocppService.isChargerConnected(serial);

        res.json({
            success: true,
            charger: {
                serial: charger.serial_number,
                status: charger.status,
                networkStatus: charger.network_status,
                connected: isConnected,
                lastUpdated: charger.last_updated
            }
        });
    } catch (error) {
        console.error('Error consultando estado:', error);
        res.status(500).json({ success: false, error: 'Error interno' });
    }
});

// Comando: Iniciar carga remota
router.post('/remote-start/:serial', async (req, res) => {
    try {
        const { serial } = req.params;
        const { connectorId = 1, idTag } = req.body;

        if (!idTag) {
            return res.status(400).json({ 
                success: false, 
                error: 'idTag requerido' 
            });
        }

        const payload = {
            connectorId,
            idTag
        };

        const success = await ocppService.sendCommand(serial, 'RemoteStartTransaction', payload);
        
        if (success) {
            res.json({ 
                success: true, 
                message: 'Comando de inicio enviado correctamente' 
            });
        } else {
            res.status(400).json({ 
                success: false, 
                error: 'Cargador no conectado' 
            });
        }
    } catch (error) {
        console.error('Error enviando remote start:', error);
        res.status(500).json({ success: false, error: 'Error interno' });
    }
});

// Comando: Detener carga remota
router.post('/remote-stop/:serial', async (req, res) => {
    try {
        const { serial } = req.params;
        const { transactionId } = req.body;

        if (!transactionId) {
            return res.status(400).json({ 
                success: false, 
                error: 'transactionId requerido' 
            });
        }

        const payload = {
            transactionId: parseInt(transactionId)
        };

        const success = await ocppService.sendCommand(serial, 'RemoteStopTransaction', payload);
        
        if (success) {
            res.json({ 
                success: true, 
                message: 'Comando de detención enviado correctamente' 
            });
        } else {
            res.status(400).json({ 
                success: false, 
                error: 'Cargador no conectado' 
            });
        }
    } catch (error) {
        console.error('Error enviando remote stop:', error);
        res.status(500).json({ success: false, error: 'Error interno' });
    }
});

// Comando: Reiniciar cargador
router.post('/reset/:serial', async (req, res) => {
    try {
        const { serial } = req.params;
        const { type = 'Soft' } = req.body; // 'Hard' o 'Soft'

        const payload = { type };

        const success = await ocppService.sendCommand(serial, 'Reset', payload);
        
        if (success) {
            res.json({ 
                success: true, 
                message: `Comando de reinicio ${type} enviado` 
            });
        } else {
            res.status(400).json({ 
                success: false, 
                error: 'Cargador no conectado' 
            });
        }
    } catch (error) {
        console.error('Error enviando reset:', error);
        res.status(500).json({ success: false, error: 'Error interno' });
    }
});

// Comando: Desbloquear conector
router.post('/unlock-connector/:serial', async (req, res) => {
    try {
        const { serial } = req.params;
        const { connectorId = 1 } = req.body;

        const payload = { connectorId };

        const success = await ocppService.sendCommand(serial, 'UnlockConnector', payload);
        
        if (success) {
            res.json({ 
                success: true, 
                message: 'Comando de desbloqueo enviado' 
            });
        } else {
            res.status(400).json({ 
                success: false, 
                error: 'Cargador no conectado' 
            });
        }
    } catch (error) {
        console.error('Error enviando unlock:', error);
        res.status(500).json({ success: false, error: 'Error interno' });
    }
});

export default router;