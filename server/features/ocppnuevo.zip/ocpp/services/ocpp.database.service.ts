import { 
    ChargePoint, 
    Transaction, 
    MeterValue 
} from '../models';
import { 
    ChargePointStatus, 
    BootNotificationRequest,
    StartTransactionRequest,
    StopTransactionRequest
} from '../types/ocpp.types';

export class OCPPDatabaseService {
    // Métodos para ChargePoint
    async updateChargePointStatus(chargePointId: string, status: ChargePointStatus) {
        try {
            const [chargePoint] = await ChargePoint.upsert({
                chargePointId,
                status,
                lastHeartbeat: new Date()
            });
            return chargePoint;
        } catch (error) {
            console.error('Error actualizando estado del punto de carga:', error);
            throw error;
        }
    }

    async registerBootNotification(chargePointId: string, bootNotification: BootNotificationRequest) {
        try {
            const [chargePoint] = await ChargePoint.upsert({
                chargePointId,
                vendor: bootNotification.chargePointVendor,
                model: bootNotification.chargePointModel,
                serialNumber: bootNotification.chargePointSerialNumber || chargePointId,
                firmwareVersion: bootNotification.firmwareVersion,
                status: ChargePointStatus.Available,
                lastBootNotification: new Date(),
                lastHeartbeat: new Date()
            });
            return chargePoint;
        } catch (error) {
            console.error('Error registrando boot notification:', error);
            throw error;
        }
    }

    async updateHeartbeat(chargePointId: string) {
        try {
            await ChargePoint.update(
                { lastHeartbeat: new Date() },
                { where: { chargePointId } }
            );
        } catch (error) {
            console.error('Error actualizando heartbeat:', error);
            throw error;
        }
    }

    // Métodos para Transaction
    async startTransaction(chargePointId: string, request: StartTransactionRequest) {
        try {
            const transaction = await Transaction.create({
                chargePointId,
                connectorId: request.connectorId,
                idTag: request.idTag,
                startTime: new Date(request.timestamp),
                meterStart: request.meterStart,
                status: 'Started'
            });

            // Actualizar estado del punto de carga
            await this.updateChargePointStatus(chargePointId, ChargePointStatus.Charging);

            return transaction;
        } catch (error) {
            console.error('Error iniciando transacción:', error);
            throw error;
        }
    }

    async stopTransaction(chargePointId: string, request: StopTransactionRequest) {
        try {
            const transaction = await Transaction.findByPk(request.transactionId);
            if (!transaction) {
                throw new Error('Transacción no encontrada');
            }

            await transaction.update({
                endTime: new Date(request.timestamp),
                meterStop: request.meterStop,
                status: 'Completed'
            });

            // Actualizar estado del punto de carga
            await this.updateChargePointStatus(chargePointId, ChargePointStatus.Available);

            return transaction;
        } catch (error) {
            console.error('Error deteniendo transacción:', error);
            throw error;
        }
    }

    // Métodos para MeterValue
    async addMeterValue(transactionId: number, timestamp: Date, value: number, unit: string = 'Wh') {
        try {
            return await MeterValue.create({
                transactionId,
                timestamp,
                value,
                unit
            });
        } catch (error) {
            console.error('Error agregando valor del medidor:', error);
            throw error;
        }
    }

    // Métodos de consulta
    async getChargePointInfo(chargePointId: string) {
        try {
            return await ChargePoint.findOne({
                where: { chargePointId },
                include: [{
                    model: Transaction,
                    as: 'transactions',
                    where: { status: 'Started' },
                    required: false,
                    limit: 1,
                    order: [['startTime', 'DESC']]
                }]
            });
        } catch (error) {
            console.error('Error obteniendo información del punto de carga:', error);
            throw error;
        }
    }

    async getActiveTransactions() {
        try {
            return await Transaction.findAll({
                where: { status: 'Started' },
                include: [{
                    model: ChargePoint,
                    as: 'chargePoint'
                }]
            });
        } catch (error) {
            console.error('Error obteniendo transacciones activas:', error);
            throw error;
        }
    }

    async getTransactionHistory(chargePointId: string, limit: number = 10) {
        try {
            return await Transaction.findAll({
                where: { chargePointId },
                include: [{
                    model: MeterValue,
                    as: 'meterValues'
                }],
                order: [['startTime', 'DESC']],
                limit
            });
        } catch (error) {
            console.error('Error obteniendo historial de transacciones:', error);
            throw error;
        }
    }
}