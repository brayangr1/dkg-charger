// server/features/ocpp/services/ocpp.service.ts
import { OCPPDatabaseService } from './ocpp.database.service';
import { connectionPool } from '../../../config/db.config';

export class OCPPService {
    private dbService: OCPPDatabaseService;
    private connectedChargers: Map<string, any> = new Map();

    constructor() {
        this.dbService = new OCPPDatabaseService();
    }

    // Registrar cargador conectado
    registerCharger(chargePointId: string, wsConnection: any) {
        this.connectedChargers.set(chargePointId, {
            wsConnection,
            chargePointId,
            lastHeartbeat: new Date(),
            status: 'Available'
        });
        
        // Sincronizar con base de datos MySQL
        this.syncChargerWithDatabase(chargePointId);
    }

    // Sincronizar cargador OCPP con base de datos MySQL
    private async syncChargerWithDatabase(chargePointId: string) {
        try {
            // Verificar si existe en chargers table
            const [rows] = await connectionPool.query(
                'SELECT id, serial_number FROM chargers WHERE serial_number = ?',
                [chargePointId]
            );

            const chargerRows = rows as any[];
            
            if (chargerRows.length === 0) {
                console.log(`Cargador ${chargePointId} no existe en MySQL, creando registro...`);
                
                // Crear registro básico en chargers
                await connectionPool.query(
                    `INSERT INTO chargers 
                    (serial_number, name, model, max_power, firmware_version, owner_id, status, network_status, registered_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
                    [
                        chargePointId,
                        `Cargador ${chargePointId}`,
                        'Desconocido',
                        16, // 16V estándar
                        '1.0',
                        1, // Owner temporal (admin)
                        'standby',
                        'online'
                    ]
                );
                
                console.log(`Registro MySQL creado para cargador ${chargePointId}`);
            } else {
                // Actualizar estado a online
                await connectionPool.query(
                    'UPDATE chargers SET network_status = ?, last_updated = NOW() WHERE serial_number = ?',
                    ['online', chargePointId]
                );
            }
        } catch (error) {
            console.error('Error sincronizando cargador con MySQL:', error);
        }
    }

    // Enviar comando a cargador
    async sendCommand(chargePointId: string, action: string, payload: any): Promise<boolean> {
        const charger = this.connectedChargers.get(chargePointId);
        if (!charger) {
            console.error(`Cargador ${chargePointId} no conectado`);
            return false;
        }

        try {
            const message = [
                2, // MessageType CALL
                this.generateUniqueId(),
                action,
                payload
            ];

            charger.wsConnection.send(JSON.stringify(message));
            console.log(`Comando ${action} enviado a ${chargePointId}`);
            return true;
        } catch (error) {
            console.error(`Error enviando comando a ${chargePointId}:`, error);
            return false;
        }
    }

    private generateUniqueId(): string {
        return Date.now().toString() + Math.random().toString(36).substr(2, 9);
    }

    // Obtener estado de cargadores conectados
    getConnectedChargers() {
        const chargers: any[] = [];
        this.connectedChargers.forEach((charger, chargePointId) => {
            chargers.push({
                chargePointId,
                status: charger.status,
                lastHeartbeat: charger.lastHeartbeat,
                connected: true
            });
        });
        return chargers;
    }

    // Verificar si cargador está conectado
    isChargerConnected(chargePointId: string): boolean {
        return this.connectedChargers.has(chargePointId);
    }
} 