import express from 'express';
import { WebSocketServer } from 'ws';
import { createServer } from 'http';
import dotenv from 'dotenv';
import OCPPServer from './services/ocpp.server';

dotenv.config();

const app = express();
const server = createServer(app);
//const wss = new WebSocketServer({ server });

// Puerto unificado
const PORT = process.env.PORT || 5010;

const ocppServer = new OCPPServer(5010);
console.log('🚀 Servidor OCPP custom iniciado');


/*Configuración WebSocket para OCPP
wss.on('connection', (ws, req) => {
    console.log('Nueva conexión OCPP:', req.url);

    ws.on('message', (message) => {
        console.log('Mensaje recibido:', message.toString());
        // Aquí puedes procesar los mensajes OCPP
    });

    ws.on('close', () => {
        console.log('Conexión cerrada');
    });
});
 */
// Rutas API Express existentes
app.get('/api/status', (req, res) => {
    res.json({ status: 'ok' });
});

// Iniciar servidor unificado
server.listen(PORT, () => {
    console.log(`Servidor unificado (API + OCPP) escuchando en puerto ${PORT}`);
});

export default ocppServer;